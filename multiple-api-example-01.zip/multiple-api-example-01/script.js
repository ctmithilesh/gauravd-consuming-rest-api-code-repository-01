const newsHeadline = document.getElementById('headline')
const aImage = document.getElementById('article-image')
const aDescription = document.getElementById('article-description')

async function getNewsData(){

    const response = await fetch('https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=5497647da2114041ad647eba8e002d6f')
    console.log(response)
    const status = response.status 

    const data = await response.json()
    console.log(status,data) 
    if(status === 200){
        alert('Successfully fetched the news!')
    }
    else{
        alert('Something went Wrong!')
    }

    newsHeadline.innerHTML = `<h1> ${data.articles[0].title} </h1>`
    aImage.setAttribute("width","200")
    aImage.setAttribute("height","200")
    aImage.setAttribute("src",`${data.articles[0].urlToImage}`)
    aDescription.innerHTML = `<p> ${data.articles[0].description} </p>`
   
}
getNewsData()