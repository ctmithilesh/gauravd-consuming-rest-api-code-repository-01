// const userData = document.getElementById('user')
// async function getUsersData(){

//     try{
//         const response = await fetch('https://reqres.in/api/users?page=1')
//         const status = response.status 
//         const data = await response.json()
//         console.log(status,data)
//         console.log(data.data)  
//         if(status === 200){
//                     userData.innerHTML = `
//                     <div>    
//                     <h1> ${data.data[0].first_name} </h1>
//                     <img src=${data.data[0].avatar} />
//                     <h3> ${data.data[0].email} </h3>
//                     </div>
//                 `
//         }

//     }
//     catch(e){
//         console.log(e)
//         userData.innerHTML = `<h1> ${e} </h1>`

//     }
    
// }

// getUsersData()


async function submitUserData(){

    const data = {
            "name": "morpheus",
            "job": "leader"
    }


    const response = await fetch('https://reqres.in/api/users',{
        method:'POST',
        body:JSON.stringify(data),
        headers:{
            "content-type":"application/json"
        }
    })
    console.log(response)
    
}
submitUserData()