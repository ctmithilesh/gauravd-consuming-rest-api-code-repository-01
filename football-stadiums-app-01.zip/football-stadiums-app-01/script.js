const x = document.getElementById('stadium')

async function getData(){

        const response = await fetch('https://myfakeapi.com/api/football')
        const data = await response.json()
        console.log(data)
        const status = response.status

        const myData = data.football.stadiums
        console.log(myData)

        if(status === 200){

            for(let i=0;i<=myData.length;i++){

                x.innerHTML += `
                <div>
                    <h3> ${myData[i].name} </h3>
                    <img
                        src=${myData[i].image}
                        width="200"
                        height="200"
                    />
                </div>
               
               
               `
                
            }
               
        }


}
getData()